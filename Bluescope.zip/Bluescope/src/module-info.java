/**
 * 
 */
/**
 * 
 */
module Bluescope {
	requires java.sql;
}